const LINE = '*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*'
const FOOT = '© ʙʏ ʀɪᴅɪɴ'
const frame = (...lines) => `${LINE}\n${lines.join('\n')}\n${LINE}\n${FOOT}`

// مفاتيح نظام اللغة (النصوص نفسها في ملف اللغات)
const HEAD = '{chatgroup_msg}'
const OPEN = '{chatgroup_open_msg}'
const CLOSE = '{chatgroup_close_msg}'
const CANCEL = '{chatgroup_cancel_msg}'
const USAGE = '{chatgroup_usage_msg}'
const BADTIME = '{chatgroup_badtime_msg}'

// أمثلة مش محتاجة ترجمة
const EXAMPLES = '.شات فتح\n.شات قفل\n.شات فتح 5\n.شات قفل 10h\n5s · 5m · 5h · 5d'

// مؤقتات كل قروب (global عشان تفضل شغالة حتى لو الملف اتعمله reload)
global.__chatTimers = global.__chatTimers || new Map()
const timers = global.__chatTimers

// أقصى مدة setTimeout بتقبلها (~24 يوم)
const MAX_MS = 2147483647

const OPEN_WORDS = ['فتح', 'افتح', 'open', 'on']
const CLOSE_WORDS = ['قفل', 'اقفل', 'أقفل', 'close', 'off']

const UNIT_GROUPS = [
  { ms: 1000, short: 's', keys: ['s', 'sec', 'ث', 'ثانيه', 'ثانية', 'ثواني', 'ثوانى'] },
  { ms: 60 * 1000, short: 'm', keys: ['', 'm', 'min', 'د', 'دقيقه', 'دقيقة', 'دقايق', 'دقائق'] },
  { ms: 60 * 60 * 1000, short: 'h', keys: ['h', 'hr', 'س', 'ساعه', 'ساعة', 'ساعات'] },
  { ms: 24 * 60 * 60 * 1000, short: 'd', keys: ['d', 'day', 'days', 'ي', 'يوم', 'ايام', 'أيام'] },
]

const UNIT_LOOKUP = {}
for (const group of UNIT_GROUPS) {
  for (const key of group.keys) UNIT_LOOKUP[key] = group
}

// أرقام عربية (٠-٩) وفارسية (۰-۹) → إنجليزي
function toAsciiDigits(value) {
  return String(value)
    .replace(/[\u0660-\u0669]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(/[\u06F0-\u06F9]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .replace(/\u066B/g, '.')
}

function parseDuration(raw) {
  const clean = toAsciiDigits(raw).replace(/\s+/g, '').toLowerCase()
  if (!clean) return { none: true }

  const match = clean.match(/^(\d+(?:\.\d+)?)(\D*)$/)
  if (!match) return { error: true }

  const value = parseFloat(match[1])
  const unit = UNIT_LOOKUP[match[2]]

  if (!unit || !(value > 0)) return { error: true }

  return { ms: Math.round(value * unit.ms), value, unit }
}

let handler = async (m, { conn, args }) => {
  await m.react('⚡')

  const action = (args[0] || '').toLowerCase()
  const wantOpen = OPEN_WORDS.includes(action)
  const wantClose = CLOSE_WORDS.includes(action)

  if (!wantOpen && !wantClose) {
    return m.reply(frame(HEAD, USAGE, EXAMPLES))
  }

  const dur = parseDuration(args.slice(1).join(' '))

  if (dur.error || (!dur.none && (dur.ms < 1000 || dur.ms > MAX_MS))) {
    return m.reply(frame(HEAD, BADTIME, EXAMPLES))
  }

  const chat = m.chat
  const setting = wantOpen ? 'not_announcement' : 'announcement'
  const revert = wantOpen ? 'announcement' : 'not_announcement'
  const stateMsg = wantOpen ? OPEN : CLOSE

  // أي عد تنازلي قديم للقروب ده يتلغي
  const hadTimer = timers.has(chat)
  if (hadTimer) {
    clearTimeout(timers.get(chat))
    timers.delete(chat)
  }

  await conn.groupSettingUpdate(chat, setting)

  // ── بدون مدة: فتح/قفل دايم ─────────────────────────────────────────────────
  if (dur.none) {
    return m.reply(frame(HEAD, stateMsg, ...(hadTimer ? [CANCEL] : [])))
  }

  // ── بمدة: يرجّع الحالة بعد ما الوقت يخلص ──────────────────────────────────
  const label = `${dur.value}${dur.unit.short}`

  const timer = setTimeout(async () => {
    timers.delete(chat)

    try {
      await conn.groupSettingUpdate(chat, revert)

      // الرسالة دي بتتبعت بعدين، فنثبّت لغة القروب ده قبل الإرسال
      try {
        const { useLang } = await import('../lib/lang.js')
        useLang(chat)
      } catch {}

      await conn.sendMessage(chat, {
        text: frame(HEAD, `⏰ ${wantOpen ? CLOSE : OPEN}`),
      })
    } catch (error) {
      console.log('شات.js revert failed:', error?.message)
    }
  }, dur.ms)

  timers.set(chat, timer)

  return m.reply(frame(HEAD, stateMsg, `⏱ ${label} ➜ ${wantOpen ? '🔒' : '🔓'}`))
}

handler.help = ['شات']
handler.tags = ['group']
handler.command = /^شات$/i
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler
