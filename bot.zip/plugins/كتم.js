// ╔════════════════════════════════════╗
// ║  Mute System — by RAGE             ║
// ╚════════════════════════════════════╝

const num = (j = '') => String(j).split('@')[0].split(':')[0]

const MUTE_IMG = 'https://telegra.ph/file/f8324d9798fa2ed2317bc.png'
const UNMUTE_IMG = 'https://telegra.ph/file/aea704d0b242b8c41bf15.png'

// كل الأشكال الممكنة للعضو (LID / رقم) من بيانات الجروب
async function resolveAliases(conn, chat, jid) {
  const dec = (x) => (conn.decodeJid ? conn.decodeJid(x) : x)
  const set = new Set([dec(jid)])
  let meta = null
  try {
    meta = await conn.groupMetadata(chat)
    const t = num(jid)
    for (const p of meta.participants || []) {
      const ids = [p.id, p.jid, p.lid, p.phoneNumber].filter((x) => typeof x === 'string' && x.includes('@'))
      if (ids.some((x) => num(x) === t)) {
        ids.forEach((x) => set.add(dec(x)))
        break
      }
    }
  } catch (e) {
    console.error('[mute] groupMetadata failed:', e.message)
  }
  return { aliases: [...set], meta }
}

// رسالة الاقتباس (لو الصورة فشلت بنكمل من غيرها بدل ما الأمر يقع)
async function makeQuoted(isMute) {
  let thumb
  try {
    const r = await fetch(isMute ? MUTE_IMG : UNMUTE_IMG, { signal: AbortSignal.timeout(5000) })
    if (r.ok && /image/i.test(r.headers.get('content-type') || '')) {
      thumb = Buffer.from(await r.arrayBuffer())
    }
  } catch {}
  return {
    key: { participants: '0@s.whatsapp.net', fromMe: false, id: 'RAGE' },
    message: {
      locationMessage: {
        name: 'Mute System ✅',
        ...(thumb ? { jpegThumbnail: thumb } : {}),
      },
    },
    participant: '0@s.whatsapp.net',
  }
}

const handler = async (message, { conn, command, isAdmin }) => {
  if (!message.isGroup) return
  if (!isAdmin) return conn.reply(message.chat, '⚡ *فـقـط الـمـسـؤولـيـن يـمـكـنـهـم تـنـفـيـذ هـذا الأمـر*', message)

  const isMute = command === 'كتم'

  const targetJid = message.mentionedJid?.[0] || message.quoted?.sender || null
  if (!targetJid) {
    return conn.reply(
      message.chat,
      isMute
        ? '⚡ *مـن فـضـلـك مـنـشـن الـشـخـص لـكـتـمـه*'
        : '⚡ *مـن فـضـلـك مـنـشـن الـشـخـص لـفـك الـكـتـم*',
      message
    )
  }

  const { aliases, meta } = await resolveAliases(conn, message.chat, targetJid)
  const targetNums = aliases.map(num)
  const hit = (list) => list.filter(Boolean).map(num).some((n) => targetNums.includes(n))

  // حماية البوت
  if (hit([conn.user?.id, conn.user?.jid, conn.user?.lid])) {
    return conn.reply(message.chat, '❌️⃝❄ *لا يـمـكـنـك تـنـفـيـذ الأمـر عـلـى الـبـوت*', message)
  }

  // حماية المطورين
  const owners = (global.owner || []).map((v) => (Array.isArray(v) ? v[0] : v))
  if (hit(owners)) {
    return conn.reply(message.chat, '👑⃝⚡ *لا يـمـكـن تـنـفـيـذ الأمـر عـلـى مـطـور الـبـوت*', message)
  }

  // حماية صاحب الجروب
  if (hit([meta?.owner, meta?.ownerPn])) {
    return conn.reply(message.chat, '❌️⃝❄ *لا يـمـكـنـك تـنـفـيـذ الأمـر عـلـى صـاحـب الـمـجـمـوعـة*', message)
  }

  const users = global.db.data.users
  const alreadyMuted = aliases.some((a) => users[a]?.muto === true)

  if (isMute && alreadyMuted) {
    return conn.reply(message.chat, '⏳⃝⚡ *هـذا الـمـسـتـخـدم مـكـتـوم بـالـفـعـل*', message)
  }
  if (!isMute && !alreadyMuted) {
    return conn.reply(message.chat, '⏳⃝⚡ *هـذا الـمـسـتـخـدم غـيـر مـكـتـوم*', message)
  }

  // نطبّق الكتم على كل أشكال الـ JID عشان يشتغل سواء ظهر كـ LID أو رقم
  for (const a of aliases) {
    if (!users[a]) users[a] = {}
    users[a].muto = isMute
  }
  console.log(`[mute] ${isMute ? 'MUTED' : 'UNMUTED'}:`, aliases.join(', '))

  await message.react('✅')

  try {
    const quoted = await makeQuoted(isMute)
    await conn.reply(
      message.chat,
      isMute
        ? '* ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  𝗥𝗔𝗚𝗘 𝗕𝗢𝗧 𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙*\n\n*تـم كـتـم الـعـضـو بـنـجـاح 🔇⃝⚡*'
        : '* ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  𝗥𝗔𝗚𝗘 𝗕𝗢𝗧 𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙*\n\n*تـم إلـغـاء كـتـم الـعـضـو 🔊⃝🌙*',
      quoted,
      { mentions: [targetJid] }
    )
  } catch (e) {
    console.error('[mute] reply failed:', e.message)
  }
}

// حذف رسائل المكتوم (المسؤولين مستثنين)
handler.all = async function (m) {
  try {
    if (!m.isGroup || m.fromMe) return
    if (!global.db.data.users?.[m.sender]?.muto) return

    const meta = await this.groupMetadata(m.chat)
    const t = num(m.sender)
    const p = (meta.participants || []).find((x) =>
      [x.id, x.jid, x.lid, x.phoneNumber].filter(Boolean).some((id) => num(id) === t)
    )
    if (p?.admin) return

    await this.sendMessage(m.chat, { delete: m.key })
  } catch (e) {
    console.error('[mute] delete failed:', e.message)
  }
}

handler.help = ['كتم ⃝⚡', 'فك_الكتم ⃝🌙']
handler.command = /^(كتم|فك_الكتم)$/i
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler
