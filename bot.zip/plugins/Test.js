let handler = async (m, { usedPrefix, command }) => {
  await m.react('⚡')
  return m.reply(`*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*
{test_msg}
*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*
© ʙʏ ɴɪᴠʏ`.trim())
}

handler.help = ['test']
handler.tags = ['main']
// الأمر الأصلي: test — والاختصارات (تست / test ...) من language/commands.txt
// تركت تست هنا أيضاً عشان يشتغل حتى لو نظام اللغة متوقف
handler.command = /^(test|تست)$/i

export default handler
