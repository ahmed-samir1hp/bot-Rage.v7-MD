// ╔════════════════════════════════════╗
// ║  JID Command — by RAGE             ║
// ╚════════════════════════════════════╝

import fs from 'fs'
import path from 'path'

const HEAD = '* ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  𝗥𝗔𝗚𝗘 𝗕𝗢𝗧 𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙*\n\n'

// القناة الوهمية اللي الرد بيطلع منها
const FAKE_NEWSLETTER = {
  newsletterJid: '120363411851445298@newsletter',
  newsletterName: 'RAGE-Bot | JID 🆔',
  serverMessageId: 1,
}

function getThumb() {
  try {
    const p = path.resolve(process.cwd(), 'src', 'nivyhp.jpg')
    if (fs.existsSync(p)) return fs.readFileSync(p)
  } catch {}
  return undefined
}

function buildContext() {
  return {
    forwardingScore: 999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: { ...FAKE_NEWSLETTER },
    externalAdReply: {
      title: '𝚁𝙰𝙶𝙴',
      body: '𝚁𝙸𝙳𝙸𝙽',
      mediaType: 2,
      thumbnail: getThumb(),
      sourceUrl: 'https://instagram.com',
    },
  }
}

// رد نصي من "القناة" الوهمية
function say(conn, to, text, quoted) {
  return conn.sendMessage(to, { text, contextInfo: buildContext() }, quoted ? { quoted } : {})
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const inChannel = (m.chat || '').endsWith('@newsletter')

  // الرد دايماً في نفس الشات / المجموعة / القناة
  const to = m.chat
  const quoted = inChannel ? undefined : m // الاقتباس مش بيشتغل جوه القنوات

  const arg = (text || '').trim()
  let jid = ''
  let name = ''
  let type = ''

  try {
    const ch = arg.match(/whatsapp\.com\/channel\/([\w-]+)/i)
    const gr = arg.match(/chat\.whatsapp\.com\/([\w-]+)/i)

    if (ch) {
      // رابط قناة
      const meta = await conn.newsletterMetadata('invite', ch[1])
      jid = meta?.id || ''
      name = meta?.name || meta?.thread_metadata?.name?.text || ''
      type = 'قـنـاة 📢'
    } else if (gr) {
      // رابط جروب
      const info = await conn.groupGetInviteInfo(gr[1])
      jid = info?.id || ''
      if (jid && !jid.includes('@')) jid += '@g.us'
      name = info?.subject || ''
      type = 'مـجـمـوعـة 👥'
    } else {
      // رد على منشور محوّل من قناة
      const q = m.quoted
      const nl =
        q?.msg?.contextInfo?.forwardedNewsletterMessageInfo ||
        q?.contextInfo?.forwardedNewsletterMessageInfo

      if (nl?.newsletterJid) {
        jid = nl.newsletterJid
        name = nl.newsletterName || ''
        type = 'قـنـاة 📢'
      } else {
        // الشات / القناة اللي اتكتب فيها الأمر
        jid = m.chat
        if (jid.endsWith('@g.us')) {
          type = 'مـجـمـوعـة 👥'
          name = (await conn.groupMetadata(jid).catch(() => null))?.subject || ''
        } else if (inChannel) {
          type = 'قـنـاة 📢'
          name = (await conn.newsletterMetadata('jid', jid).catch(() => null))?.name || ''
        } else {
          type = 'مـحـادثـة خـاصـة 💬'
        }
      }
    }
  } catch (e) {
    console.error('[jid]', e?.message || e)
    return say(conn, to, HEAD + '*⚠️ مـا قـدرت أجـيـب الـبـيـانـات، تـأكـد مـن الـرابـط*', quoted)
  }

  if (!jid) return say(conn, to, HEAD + '*⚠️ مـا لـقـيـت JID*', quoted)

  await m.react('✅').catch(() => {})

  let out = HEAD
  out += `*📂 الـنـوع:* ${type}\n`
  if (name) out += `*📛 الاسـم:* ${name}\n`
  out += `\n*🆔 JID:*\n` + '```' + jid + '```\n'
  out += `\n_💡 ${usedPrefix}${command} + رابط قناة/مجموعة، أو رد على منشور محوّل من قناة_`

  await say(conn, to, out, quoted)
}

handler.help = ['jid']
handler.tags = ['tools']
handler.command = /^jid$/i

export default handler
