import { languageMenu, setPending, sendFancy } from '../lib/lang.js'

let handler = async (m, extra) => {
  const conn = extra?.conn
  try { await m.react('🌐') } catch {}
  const menu = languageMenu(m.chat)
  setPending(m)                                   // ينتظر رد المستخدم برقم (0.1 … 1.0)
  try {
    return await sendFancy(m.chat, menu, m, conn) // القائمة داخل القناة الوهمية
  } catch (e) {
    console.error('[language] فشل الإرسال داخل القناة:', e?.stack || e)
    return m.reply(menu)                          // احتياطي: يرسلها كرسالة عادية
  }
}

handler.help = ['language']
handler.tags = ['main']
// الأمر الأصلي: language — الاختصارات (لغة / language / भाषा / ...) من language/commands.txt
handler.command = /^(language|lang|لغة|اللغة)$/i

export default handler
