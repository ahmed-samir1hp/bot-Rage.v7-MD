/*
• أمر SoundCloud — كل الردود بتظهر كأنها محوّلة من قناة (newsletter)
• .soundcloud <كلمة> أو <رابط>   (الاختصارات بكل اللغات في language/commands3.txt)
• النصوص حسب لغة الشات من language/texts4.txt
• كله بالذاكرة، بدون ملفات مؤقتة
• © RAGE BOT — Developer: RIDIN
*/

import baileys from '@whiskeysockets/baileys'
import axios from 'axios'
import fs from 'fs'
import path from 'path'
import { spawn } from 'child_process'
import { t } from '../lib/lang.js'

const { generateWAMessageContent, generateWAMessageFromContent, proto } = baileys

const SC_API = 'https://api-v2.soundcloud.com'
const NEWSLETTER_ID = '120363411851445298@newsletter' // قناة التقارير
const MAX_BYTES = 200 * 1024 * 1024
const DOC_THRESHOLD = 40 * 1024 * 1024 // أكبر من كده يتبعت document
const FOOTER = '🎧 SoundCloud • © RAGE BOT | DEV: RIDIN'
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'

// خطأ بمفتاح نص (يُترجم حسب لغة الشات عند العرض)
class ScError extends Error {
  constructor(key, vars = {}) { super(key); this.key = key; this.vars = vars }
}
const errText = (e, chat) => (e?.key ? t(e.key, chat, e.vars) : (e?.message || String(e)))

// ============================================
// القناة الوهمية اللي كل الردود بتطلع منها
// ============================================
const FAKE_NEWSLETTER = {
  newsletterJid: '120363411851445298@newsletter',
  newsletterName: 'RAGE-Bot | sound cloud 🎵',
  serverMessageId: 1,
}

async function buildContext(extra = {}) {
  const thumbnail = await getNivyThumbnail()
  return {
    forwardingScore: 999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: { ...FAKE_NEWSLETTER },
    externalAdReply: {
      title: '𝚁𝙰𝙶𝙴',
      body: '𝚁𝙸𝙳𝙸𝙽',
      mediaType: 2,
      thumbnail: thumbnail || undefined,
      sourceUrl: 'https://instagram.com',
    },
    ...extra,
  }
}

// رد نصي عادي لكن من "القناة"
async function say(conn, m, text) {
  return conn.sendMessage(m.chat, { text, contextInfo: await buildContext() }, { quoted: m })
}

function formatDuration(ms) {
  if (!ms) return '0:00'
  const s = Math.floor(ms / 1000)
  return `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`
}

function isSoundCloudUrl(text) {
  return /^https?:\/\/(www\.|m\.|on\.)?soundcloud\.com\/[^\s]+/i.test(text.trim())
}

// ============================================
// Client ID (مع كاش ساعة)
// ============================================
let cachedClientId = null
let cachedAt = 0

async function getSoundCloudClientId(force = false) {
  if (!force && cachedClientId && Date.now() - cachedAt < 60 * 60 * 1000) return cachedClientId

  const headers = { 'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9' }
  const html = await axios.get('https://soundcloud.com/', { headers, timeout: 20000 })
  const urls = html.data.match(/https:\/\/a-v2\.sndcdn\.com\/assets\/[a-zA-Z0-9-]+\.js/g) || []
  if (!urls.length) throw new Error('No JS bundles found')

  for (let i = urls.length - 1; i >= 0; i--) {
    try {
      const js = (await axios.get(urls[i], { headers, timeout: 15000 })).data
      const m = js.match(/[,{]client_id:"([a-zA-Z0-9_-]{20,40})"/) ||
                js.match(/client_id=([a-zA-Z0-9_-]{20,40})/) ||
                js.match(/clientId:"([a-zA-Z0-9_-]{20,40})"/)
      if (m?.[1]) {
        cachedClientId = m[1]
        cachedAt = Date.now()
        return cachedClientId
      }
    } catch { continue }
  }
  throw new Error('Could not find client_id')
}

function createScClient() {
  return axios.create({
    timeout: 20000,
    headers: { 'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9', 'Accept': 'application/json' },
  })
}

function mapTrack(item) {
  return {
    id: item.id,
    title: item.title || 'Unknown',
    artist: item.user?.username || 'Unknown',
    permalink: item.permalink_url,
    artwork: item.artwork_url || '',
    avatar: item.user?.avatar_url || '',
    duration: item.duration || 0,
    playCount: item.playback_count || 0,
    media: item.media,
    auth: item.track_authorization,
  }
}

async function searchTracks(clientId, query, limit = 6) {
  try {
    const r = await createScClient().get(`${SC_API}/search/tracks`, {
      params: { q: query, client_id: clientId, limit },
    })
    return (r.data.collection || []).filter(t => t.kind === 'track' && t.streamable !== false).map(mapTrack)
  } catch (e) {
    console.error('[SoundCloud] Search error:', e.message)
    return []
  }
}

async function resolveUrl(clientId, url) {
  try {
    const r = await createScClient().get(`${SC_API}/resolve`, { params: { url, client_id: clientId } })
    if (r.data?.kind === 'track') return mapTrack(r.data)
  } catch (e) {
    console.error('[SoundCloud] Resolve error:', e.message)
  }
  return null
}

// ============================================
// كل روابط البث المتاحة: progressive أولاً، بعدين HLS (mp3)، بعدين أي HLS
// ============================================
async function getStreamCandidates(clientId, track) {
  const client = createScClient()
  let transcodings = track.media?.transcodings
  let auth = track.auth

  if (!transcodings?.length || !auth) {
    const r = await client.get(`${SC_API}/tracks/${track.id}`, { params: { client_id: clientId } })
    transcodings = r.data.media?.transcodings
    auth = r.data.track_authorization
  }
  if (!transcodings?.length) throw new ScError('sc_err_nostream')

  const isMp3 = x => /audio\/mpeg/i.test(x.format?.mime_type || '')
  const ordered = [
    ...transcodings.filter(x => x.format?.protocol === 'progressive'),
    ...transcodings.filter(x => x.format?.protocol === 'hls' && isMp3(x)),
    ...transcodings.filter(x => x.format?.protocol === 'hls' && !isMp3(x)),
  ]

  const out = []
  let lastErr
  for (const x of ordered) {
    try {
      const r = await client.get(x.url, { params: { client_id: clientId, track_authorization: auth } })
      if (r.data?.url) {
        out.push({
          url: r.data.url,
          type: x.format.protocol === 'progressive' ? 'progressive' : (isMp3(x) ? 'hls-mp3' : 'hls-other'),
        })
      }
    } catch (e) {
      lastErr = e
      console.error('[SoundCloud] stream error:', e.response?.status || e.message)
    }
  }
  if (!out.length) {
    throw new ScError('sc_err_streamfail', {
      status: lastErr?.response?.status ? ` (HTTP ${lastErr.response.status})` : '',
    })
  }
  return out
}

// ============================================
// التحميل (بالذاكرة)
// ============================================
const dlHeaders = { 'User-Agent': UA, 'Accept': '*/*', 'Origin': 'https://soundcloud.com', 'Referer': 'https://soundcloud.com/' }

async function downloadProgressive(url) {
  const r = await axios.get(url, {
    responseType: 'arraybuffer', timeout: 300000,
    maxContentLength: MAX_BYTES, maxBodyLength: MAX_BYTES, headers: dlHeaders,
  })
  return Buffer.from(r.data)
}

async function downloadHlsMp3(playlistUrl) {
  const pl = await axios.get(playlistUrl, { responseType: 'text', timeout: 30000, headers: dlHeaders })
  const segs = String(pl.data).split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('#'))
    .map(l => new URL(l, playlistUrl).href)
  if (!segs.length) throw new ScError('sc_err_playlist')

  const parts = new Array(segs.length)
  let total = 0
  const BATCH = 5
  for (let i = 0; i < segs.length; i += BATCH) {
    const slice = segs.slice(i, i + BATCH)
    const res = await Promise.all(slice.map(u =>
      axios.get(u, { responseType: 'arraybuffer', timeout: 60000, headers: dlHeaders }).then(r => Buffer.from(r.data))
    ))
    res.forEach((b, j) => { parts[i + j] = b; total += b.length })
    if (total > MAX_BYTES) throw new ScError('sc_err_toobig')
  }
  return Buffer.concat(parts)
}

function ffmpegFromUrl(url) {
  return new Promise((resolve, reject) => {
    let ff
    try {
      ff = spawn('ffmpeg', ['-i', url, '-vn', '-c:a', 'libmp3lame', '-q:a', '4', '-f', 'mp3', 'pipe:1'])
    } catch (e) { return reject(new ScError('sc_err_noffmpeg')) }
    const chunks = []
    ff.stdout.on('data', c => chunks.push(c))
    ff.stderr.on('data', () => {})
    ff.on('error', () => reject(new ScError('sc_err_noffmpeg')))
    ff.on('close', code => {
      const buf = Buffer.concat(chunks)
      code === 0 && buf.length ? resolve(buf) : reject(new ScError('sc_err_ffmpegfail'))
    })
  })
}

async function downloadFullAudio(info) {
  if (info.type === 'progressive') return downloadProgressive(info.url)
  if (info.type === 'hls-mp3') {
    try { return await downloadHlsMp3(info.url) }
    catch { return ffmpegFromUrl(info.url) } // لو التحميل اليدوي فشل جرّب ffmpeg
  }
  return ffmpegFromUrl(info.url)
}

// أقل حجم منطقي للمدة (64kbps = 8000 بايت/ثانية)
const looksComplete = (buf, durationMs) =>
  !durationMs || buf.length >= (durationMs / 1000) * 8000

// يجرّب كل النسخ ويرجّع أول نسخة كاملة، وإلا أكبر نسخة نزلت
async function downloadBest(clientId, track) {
  const candidates = await getStreamCandidates(clientId, track)
  let best = null
  for (const c of candidates) {
    try {
      const buf = await downloadFullAudio(c)
      if (!buf?.length) continue
      if (looksComplete(buf, track.duration)) return buf
      if (!best || buf.length > best.length) best = buf
      console.error(`[SoundCloud] ${c.type} incomplete (${buf.length} bytes), trying next`)
    } catch (e) {
      console.error(`[SoundCloud] ${c.type} failed:`, e.key || e.message)
    }
  }
  if (best) return best
  throw new ScError('sc_err_empty')
}

// ============================================
function readLocal(...parts) {
  try {
    const p = path.resolve(process.cwd(), ...parts)
    if (fs.existsSync(p)) return fs.readFileSync(p)
  } catch {}
  return null
}

// صورة افتراضية للـ preview لو مفيش غلاف للأغنية
async function getNivyThumbnail() {
  return readLocal('src', 'nivyhp.jpg')
}

// غلاف الأغنية كـ Buffer (واتساب مش بيعرض thumbnailUrl، لازم Buffer)
async function getTrackThumbnail(track) {
  const url = (track.artwork || track.avatar || '').replace('-large.', '-t500x500.')
  if (url) {
    try {
      const r = await axios.get(url, { responseType: 'arraybuffer', timeout: 15000, headers: { 'User-Agent': UA } })
      return Buffer.from(r.data)
    } catch (e) {
      console.error('[SoundCloud] artwork download failed:', e.message)
    }
  }
  return getNivyThumbnail()
}

// التقرير يروح للقناة بلغة البوت الافتراضية
async function sendNewsletterReport(conn, d) {
  try {
    await conn.sendMessage(NEWSLETTER_ID, {
      text: t('sc_report', NEWSLETTER_ID, {
        title: d.title, artist: d.artist, duration: d.duration,
        status: d.status, time: new Date().toISOString(),
      }),
    })
  } catch (e) {
    console.error('[Newsletter] Report failed:', e.message)
  }
}

async function sendAudio(conn, m, clientId, track) {
  await m.react('🎧')

  let buffer
  try {
    try {
      buffer = await downloadBest(clientId, track)
    } catch (e) {
      clientId = await getSoundCloudClientId(true)
      buffer = await downloadBest(clientId, track)
    }
    if (!buffer?.length) throw new ScError('sc_err_empty')
  } catch (e) {
    console.error('[SoundCloud] Download error:', e.message)
    await m.react('❌')
    return say(conn, m, t('sc_download_fail', m.chat, { error: errText(e, m.chat) }))
  }

  const thumb = await getTrackThumbnail(track)
  const fileName = `${track.title.replace(/[^a-zA-Z0-9_\-\u0600-\u06FF]/g, '_')}.mp3`

  try {
    const asDoc = buffer.length > DOC_THRESHOLD
    // قناة وهمية + بيانات الأغنية في الـ externalAdReply
    const ctx = await buildContext({
      externalAdReply: {
        title: track.title,
        body: `👤 ${track.artist} | ⏱️ ${formatDuration(track.duration)}`,
        mediaType: 2,
        thumbnail: thumb || undefined,
        sourceUrl: track.permalink,
      },
    })

    const msg = await conn.sendMessage(m.chat, asDoc
      ? { document: buffer, mimetype: 'audio/mpeg', fileName, contextInfo: ctx }
      : { audio: buffer, mimetype: 'audio/mpeg', fileName, ptt: false,
          seconds: Math.round((track.duration || 0) / 1000), contextInfo: ctx },
      { quoted: m })

    await conn.sendMessage(m.chat, { react: { text: '✅', key: msg.key } })

    await sendNewsletterReport(conn, {
      title: track.title, artist: track.artist,
      duration: formatDuration(track.duration), status: '✅ Success',
    })
  } catch (e) {
    console.error('[SoundCloud] Send error:', e.message)
    say(conn, m, t('sc_send_fail', m.chat, { error: errText(e, m.chat) }))
  }
}

async function createImageMessage(conn, url) {
  try {
    const { imageMessage } = await generateWAMessageContent({ image: { url } }, { upload: conn.waUploadToServer })
    return imageMessage
  } catch { return null }
}

// ============================================
const soundCloudHandler = async (m, { conn, text, usedPrefix }) => {
  const cmd = t('soundcloud', m.chat) // اسم الأمر بلغة الشات (من commands3.txt)

  if (!text) {
    return say(conn, m, t('sc_usage', m.chat, { prefix: usedPrefix, cmd }))
  }

  await m.react('🎵')

  let clientId
  try {
    clientId = await getSoundCloudClientId()
  } catch (e) {
    await m.react('❌')
    return say(conn, m, t('sc_connect_fail', m.chat, { error: errText(e, m.chat) }))
  }

  // رابط مباشر → تحميل فوراً
  if (isSoundCloudUrl(text)) {
    const track = await resolveUrl(clientId, text.trim())
    if (!track) {
      await m.react('❌')
      return say(conn, m, t('sc_not_found', m.chat))
    }
    return sendAudio(conn, m, clientId, track)
  }

  // بحث → بطاقات
  try {
    const tracks = await searchTracks(clientId, text)
    if (!tracks.length) {
      await m.react('❌')
      return say(conn, m, t('sc_no_results', m.chat, { query: text }))
    }

    const cards = []
    for (const track of tracks) {
      const imageMsg = await createImageMessage(conn, track.artwork || 'https://cdn-icons-png.flaticon.com/512/461/461176.png')
      cards.push({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: t('sc_card', m.chat, {
            title: track.title.substring(0, 55),
            artist: track.artist,
            duration: formatDuration(track.duration),
            plays: track.playCount.toLocaleString(),
          }),
        }),
        header: proto.Message.InteractiveMessage.Header.fromObject({
          hasMediaAttachment: !!imageMsg,
          imageMessage: imageMsg || undefined,
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
          buttons: [
            { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: t('sc_btn_open', m.chat), url: track.permalink }) },
            { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: t('sc_btn_download', m.chat), id: `${usedPrefix}soundcloud ${track.permalink}` }) },
          ],
        }),
      })
    }

    const finalMessage = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.create({
              text: t('sc_results_title', m.chat, { query: text }),
            }),
            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: FOOTER }),
            // بنخلي البطاقات كمان "محوّلة من القناة"
            contextInfo: {
              forwardingScore: 999,
              isForwarded: true,
              forwardedNewsletterMessageInfo: { ...FAKE_NEWSLETTER },
            },
          }),
        },
      },
    }, { quoted: m })

    await conn.relayMessage(m.chat, finalMessage.message, { messageId: finalMessage.key.id })
    await m.react('✅')
  } catch (e) {
    console.error('[SoundCloud] Handler error:', e)
    await m.react('❌')
    say(conn, m, t('sc_error', m.chat, { error: errText(e, m.chat) }))
  }
}

soundCloudHandler.help = ['soundcloud <query>']
soundCloudHandler.tags = ['media', 'audio', 'soundcloud']
// الأمر الأصلي: soundcloud — الاختصارات (ساوند / sc / साउंडक्लाउड / ...) من language/commands3.txt
soundCloudHandler.command = /^(soundcloud|ساوند)$/i
soundCloudHandler.register = true

export default soundCloudHandler
