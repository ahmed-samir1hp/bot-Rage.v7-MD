// utils/sounds.js
// نظام تشغيل المؤثرات الصوتية على جهاز الأندرويد عبر Termux:API
// مصمم بحيث لا يتوقف تنفيذ أي أمر بسبب فشل الصوت، ويسجّل سبب الفشل بوضوح

import { exec } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import logger from './logger.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

// مجلد ملفات الصوت — غيّر المسار لو ملفاتك في مكان مختلف
const SOUNDS_DIR = path.join(__dirname, '../assets/sounds');

// خريطة الحالة -> اسم ملف الصوت
const SOUND_MAP = {
    SUCCESS : 'success.mp3',
    ERROR   : 'error.mp3',
    START   : 'start.mp3',
    CONNECT : 'connect.mp3',
    NOTIFY  : 'notify.mp3',
};

/**
 * تشغيل ملف صوتي عبر أمر termux-media-player
 * يتطلب: pkg install termux-api  +  تطبيق Termux:API من المتجر
 */
function playWithTermux(filePath) {
    return new Promise((resolve, reject) => {
        exec(`termux-media-player play "${filePath}"`, (err, stdout, stderr) => {
            if (err) return reject(new Error(stderr || err.message));
            resolve(stdout);
        });
    });
}

/**
 * تشغيل صوت حسب النوع (SUCCESS / ERROR / START / ...)
 * - لا تتوقف تنفيذ الأمر مهما حدث
 * - تسجّل في اللوج سبب أي فشل بشكل واضح
 *
 * @param {string} type - نوع الصوت (مفتاح من SOUND_MAP)
 * @returns {Promise<boolean>} - true لو نجح التشغيل
 */
export async function playSound(type = 'SUCCESS') {
    const fileName = SOUND_MAP[type] || SOUND_MAP.SUCCESS;
    const filePath = path.join(SOUNDS_DIR, fileName);

    // 1) تحقق من وجود الملف
    if (!fs.existsSync(filePath)) {
        logger.warn(`🔇 [SOUND] ملف الصوت غير موجود: ${filePath}`);
        logger.warn(`🔇 [SOUND] ضع ملفات الأصوات داخل المجلد: ${SOUNDS_DIR}`);
        return false;
    }

    // 2) تشغيل عبر Termux-API
    try {
        await playWithTermux(filePath);
        return true;
    } catch (err) {
        logger.warn(`🔇 [SOUND] فشل تشغيل (${type}): ${err.message}`);
        logger.warn('🔇 [SOUND] تأكد من تثبيت Termux:API وتنفيذ الأمر: pkg install termux-api');
        return false;
    }
}

export default { playSound };
