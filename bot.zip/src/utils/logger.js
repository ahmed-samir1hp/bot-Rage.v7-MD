// utils/logger.js — نظام تسجيل متكامل لـ Nather-Bot
import chalk from 'chalk';
import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const logsDir = path.join(__dirname, '../logs');

// إنشاء مجلد logs إذا لم يكن موجوداً
await fs.ensureDir(logsDir);

// ── تحميل ألوان الثيم من أول ما logger يشتغل ────────────────────────────────
const THEMES_DIR    = path.join(__dirname, '../themes');
const SETTINGS_FILE = path.join(THEMES_DIR, 'settings.txt');

async function initThemeColors() {
    try {
        // قراءة رقم الثيم
        if (!await fs.pathExists(SETTINGS_FILE)) return;
        const content = (await fs.readFile(SETTINGS_FILE, 'utf-8')).trim();
        const match = content.match(/\[\s*(\d+)\s*\]/);
        if (!match) return;
        const themeId = match[1];

        // البحث عن ملف .js في مجلد الثيم
        const themeDir = path.join(THEMES_DIR, themeId);
        if (!await fs.pathExists(themeDir)) return;
        const files = await fs.readdir(themeDir);
        const jsFile = files.find(f => f.endsWith('.js') || f.endsWith('.mjs'));
        if (!jsFile) return;

        // تحميل الألوان
        const themeModule = await import(`file://${path.join(themeDir, jsFile)}`);
        const colors = themeModule.colors || themeModule.default?.colors;
        if (!colors) return;

        global.themeColors = {
            info   : chalk.blue,
            warn   : chalk.yellow,
            error  : chalk.red,
            debug  : chalk.gray,
            success: chalk.green,
            ...colors,
        };
    } catch {
        // فشل صامت — الألوان الافتراضية هتشتغل
    }
}

// تحميل الألوان فوراً
await initThemeColors();

// ── الحصول على لون من الثيم النشط أو الافتراضي ───────────────────────────────
const fallback = {
    info   : chalk.blue,
    warn   : chalk.yellow,
    error  : chalk.red,
    debug  : chalk.gray,
    success: chalk.green,
};

function getColor(type) {
    return global.themeColors?.[type] || fallback[type];
}

const getTimestamp = () => new Date().toLocaleString('ar-EG', { timeZone: 'Asia/Riyadh' });

const writeToFile = async (level, message) => {
  try {
    const logFile = path.join(logsDir, `${new Date().toISOString().split('T')[0]}.log`);
    const line = `[${getTimestamp()}] [${level}] ${message}\n`;
    await fs.appendFile(logFile, line);
  } catch {}
};

const logger = {
  info: (...args) => {
    const msg = args.join(' ');
    console.log(getColor('info')(`[INFO] ${getTimestamp()} »`), msg);
    writeToFile('INFO', msg);
  },
  warn: (...args) => {
    const msg = args.join(' ');
    console.log(getColor('warn')(`[WARN] ${getTimestamp()} »`), msg);
    writeToFile('WARN', msg);
  },
  error: (...args) => {
    const msg = args.join(' ');
    console.log(getColor('error')(`[ERROR] ${getTimestamp()} »`), msg);
    writeToFile('ERROR', msg);
  },
  debug: (...args) => {
    if (process.env.DEBUG === 'true') {
      const msg = args.join(' ');
      console.log(getColor('debug')(`[DEBUG] ${getTimestamp()} »`), msg);
    }
  },
  success: (...args) => {
    const msg = args.join(' ');
    console.log(getColor('success')(`[OK] ${getTimestamp()} »`), msg);
    writeToFile('OK', msg);
  },
};

export default logger;
