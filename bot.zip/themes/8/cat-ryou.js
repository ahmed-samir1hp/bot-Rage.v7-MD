import chalk from 'chalk';

// ========== ASCII ART CAT (DETAILED) ==========
export const catArt = `
${chalk.hex('#111111')('         ⢀⣼⡿⠁   ⣾⠁  ⠸⡇   ⢿⡄ ⠘⣆  ⠹⣦')}
${chalk.hex('#111111')('       ⢠⣾⠏    ⢠⣿    ⣿    ⢻⡄  ⠹⣆  ⠹⣧')}
${chalk.hex('#000000')('      ⣴⡟     ⣾⡇    ⣿     ⢻⡄  ⠙⣦  ⢻⡄')}
${chalk.hex('#000000')('     ⣾⡟      ⣿     ⣿      ⢻⡄   ⠙⣦  ⣷')}
${chalk.hex('#000000')('    ⣸⡟      ⣿     ⣿      ⠸⡇    ⠙⣧ ⢰⡇')}
${chalk.hex('#000000')('    ⣿⠃      ⣿     ⣿       ⣷     ⠹⣆⢸⡇')}
${chalk.hex('#000000')('   ⢸⡟   ⢀⣀⣀⣉⣉⣉⣉⣉⣉⣀⣀⡀    ⢻⡄     ⢻⣼⡇')}
${chalk.hex('#000000')('   ⢸⡇  ⣰⠟⣉⣉⣉⣉⠉⠉⠉⠉⠙⠻⣄   ⢸⡇     ⢸⣿⡇')}
${chalk.hex('#000000')('   ⢸⡇ ⣾⠃ ⣾' + chalk.hex('#FFFFFF')('████') + '⡇    ⣾' + chalk.hex('#FFFFFF')('████') + '⡇  ⣿      ⢸⣿⡇')}
${chalk.hex('#000000')('   ⠘⣷ ⣿ ⠘' + chalk.hex('#FFFFFF')('⠿⠿⠟') + '⠃    ⠘' + chalk.hex('#FFFFFF')('⠿⠿⠟') + '⠃ ⢀⡿      ⣾⣿⠃')}
${chalk.hex('#000000')('    ⠹⣧⡙⠻⢧⣀⣀   ⢀⣀⣀⡤⠞⢋⣠⡾⠃     ⣼⣿⠏')}
${chalk.hex('#000000')('     ⠙⠷⣦⣄⣉⣛⠛⠛⠛⣛⣉⣠⣴⠾⠛⠁      ⣰⣿⠟')}
${chalk.hex('#000000')('        ⠉⠉⠛⠛⠛⠛⠛⠋⠉          ⣴⣿⠏')}
${chalk.hex('#000000')('                                 ⣾⣿⠁')}
`;

console.log(catArt);