// language/japanese.js — الحزمة الأساسية (الإشعارات ورسائل الصلاحيات). المفاتيح الناقصة تُؤخذ من اللغة الافتراضية.
const lenguaje = () => "ja"
const smsAvisoRG = () => "╰⊱✅⊱ *結果* ⊱✅⊱╮\n\n"
const smsAvisoAG = () => "╰⊱⚠️⊱ *警告* ⊱⚠️⊱╮\n\n"
const smsAvisoIIG = () => "╰⊱❕⊱ *情報* ⊱❕⊱╮\n\n"
const smsAvisoFG = () => "╰⊱❌⊱ *エラー* ⊱❌⊱╮\n\n"
const smsAvisoMG = () => "╰⊱❗️⊱ *誤った使い方* ⊱❗️⊱╮\n\n"
const smsAvisoEEG = () => "╰⊱📩⊱ *報告* ⊱📩⊱╮\n\n"
const smsAvisoEG = () => "╰⊱💚⊱ *成功* ⊱💚⊱╮\n\n"
const smsRowner = () => "```このコマンドはボットの作成者である私だけが使えます!!```"
const smsOwner = () => "```このコマンドは私のオーナーだけが使えます!!```"
const smsMods = () => "```このコマンドはモデレーターと私のオーナーだけが使えます!!```"
const smsPremium = () => "```このコマンドはプレミアムユーザーと私のオーナー専用です!! プレミアムは #pass premium でパスを購入してください```"
const smsGroup = () => "```このコマンドはグループでのみ使えます!!```"
const smsPrivate = () => "```このコマンドは個人チャットでのみ使えます!!```"
const smsAdmin = () => "```このコマンドは管理者専用です!!```"
const smsBotAdmin = () => "```このコマンドを使うには、私が管理者である必要があります!!```"
const smsUnreg = () => "```このコマンドを使うには登録が必要です。#verify と入力してください!!```"
const smsRestrict = () => "```このコマンドは開発者によって制限されています!!```"

export default {
lenguaje,
smsAvisoRG,
smsAvisoAG,
smsAvisoIIG,
smsAvisoFG,
smsAvisoMG,
smsAvisoEEG,
smsAvisoEG,
smsRowner,
smsOwner,
smsMods,
smsPremium,
smsGroup,
smsPrivate,
smsAdmin,
smsBotAdmin,
smsUnreg,
smsRestrict
}
