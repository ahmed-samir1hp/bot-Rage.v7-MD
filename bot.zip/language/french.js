// language/french.js — الحزمة الأساسية (الإشعارات ورسائل الصلاحيات). المفاتيح الناقصة تُؤخذ من اللغة الافتراضية.
const lenguaje = () => "fr"
const smsAvisoRG = () => "╰⊱✅⊱ *Résultat* ⊱✅⊱╮\n\n"
const smsAvisoAG = () => "╰⊱⚠️⊱ *Avertissement* ⊱⚠️⊱╮\n\n"
const smsAvisoIIG = () => "╰⊱❕⊱ *Info* ⊱❕⊱╮\n\n"
const smsAvisoFG = () => "╰⊱❌⊱ *Erreur* ⊱❌⊱╮\n\n"
const smsAvisoMG = () => "╰⊱❗️⊱ *Mauvaise utilisation* ⊱❗️⊱╮\n\n"
const smsAvisoEEG = () => "╰⊱📩⊱ *Signalement* ⊱📩⊱╮\n\n"
const smsAvisoEG = () => "╰⊱💚⊱ *Succès* ⊱💚⊱╮\n\n"
const smsRowner = () => "```Seul moi, le créateur du bot, peux utiliser cette commande !!```"
const smsOwner = () => "```Seul mon propriétaire peut utiliser cette commande !!```"
const smsMods = () => "```Seuls les modérateurs et mon propriétaire peuvent utiliser cette commande !!```"
const smsPremium = () => "```Cette commande est réservée aux utilisateurs premium et à mon propriétaire !! Pour devenir premium, achète un pass avec #pass premium```"
const smsGroup = () => "```Cette commande ne peut être utilisée que dans les groupes !!```"
const smsPrivate = () => "```Cette commande ne peut être utilisée qu'en privé !!```"
const smsAdmin = () => "```Cette commande est réservée aux admins !!```"
const smsBotAdmin = () => "```Je dois être admin pour que tu puisses utiliser cette commande !!```"
const smsUnreg = () => "```Tu dois t'inscrire pour utiliser cette commande, tape #verify !!```"
const smsRestrict = () => "```Cette commande est restreinte par mon développeur !!```"

export default {
lenguaje,
smsAvisoRG,
smsAvisoAG,
smsAvisoIIG,
smsAvisoFG,
smsAvisoMG,
smsAvisoEEG,
smsAvisoEG,
smsRowner,
smsOwner,
smsMods,
smsPremium,
smsGroup,
smsPrivate,
smsAdmin,
smsBotAdmin,
smsUnreg,
smsRestrict
}
