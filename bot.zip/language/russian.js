// language/russian.js — الحزمة الأساسية (الإشعارات ورسائل الصلاحيات). المفاتيح الناقصة تُؤخذ من اللغة الافتراضية.
const lenguaje = () => "ru"
const smsAvisoRG = () => "╰⊱✅⊱ *Результат* ⊱✅⊱╮\n\n"
const smsAvisoAG = () => "╰⊱⚠️⊱ *Предупреждение* ⊱⚠️⊱╮\n\n"
const smsAvisoIIG = () => "╰⊱❕⊱ *Информация* ⊱❕⊱╮\n\n"
const smsAvisoFG = () => "╰⊱❌⊱ *Ошибка* ⊱❌⊱╮\n\n"
const smsAvisoMG = () => "╰⊱❗️⊱ *Неверное использование* ⊱❗️⊱╮\n\n"
const smsAvisoEEG = () => "╰⊱📩⊱ *Сообщить* ⊱📩⊱╮\n\n"
const smsAvisoEG = () => "╰⊱💚⊱ *Успех* ⊱💚⊱╮\n\n"
const smsRowner = () => "```Эту команду может использовать только я, создатель бота!!```"
const smsOwner = () => "```Эту команду может использовать только мой владелец!!```"
const smsMods = () => "```Эту команду могут использовать только модераторы и мой владелец!!```"
const smsPremium = () => "```Эта команда только для премиум-пользователей и моего владельца!! Чтобы получить премиум, купите пропуск командой #pass premium```"
const smsGroup = () => "```Эту команду можно использовать только в группах!!```"
const smsPrivate = () => "```Эту команду можно использовать только в личных сообщениях!!```"
const smsAdmin = () => "```Эта команда только для администраторов!!```"
const smsBotAdmin = () => "```Мне нужно быть администратором, чтобы вы могли использовать эту команду!!```"
const smsUnreg = () => "```Для этой команды нужно зарегистрироваться, введите #verify!!```"
const smsRestrict = () => "```Эта команда ограничена моим разработчиком!!```"

export default {
lenguaje,
smsAvisoRG,
smsAvisoAG,
smsAvisoIIG,
smsAvisoFG,
smsAvisoMG,
smsAvisoEEG,
smsAvisoEG,
smsRowner,
smsOwner,
smsMods,
smsPremium,
smsGroup,
smsPrivate,
smsAdmin,
smsBotAdmin,
smsUnreg,
smsRestrict
}
