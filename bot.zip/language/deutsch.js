// language/deutsch.js — الحزمة الأساسية (الإشعارات ورسائل الصلاحيات). المفاتيح الناقصة تُؤخذ من اللغة الافتراضية.
const lenguaje = () => "de"
const smsAvisoRG = () => "╰⊱✅⊱ *Ergebnis* ⊱✅⊱╮\n\n"
const smsAvisoAG = () => "╰⊱⚠️⊱ *Warnung* ⊱⚠️⊱╮\n\n"
const smsAvisoIIG = () => "╰⊱❕⊱ *Info* ⊱❕⊱╮\n\n"
const smsAvisoFG = () => "╰⊱❌⊱ *Fehler* ⊱❌⊱╮\n\n"
const smsAvisoMG = () => "╰⊱❗️⊱ *Falsche Nutzung* ⊱❗️⊱╮\n\n"
const smsAvisoEEG = () => "╰⊱📩⊱ *Meldung* ⊱📩⊱╮\n\n"
const smsAvisoEG = () => "╰⊱💚⊱ *Erfolg* ⊱💚⊱╮\n\n"
const smsRowner = () => "```Nur ich, der Ersteller des Bots, kann diesen Befehl benutzen!!```"
const smsOwner = () => "```Nur mein Besitzer kann diesen Befehl benutzen!!```"
const smsMods = () => "```Nur Moderatoren und mein Besitzer können diesen Befehl benutzen!!```"
const smsPremium = () => "```Dieser Befehl ist nur für Premium-Nutzer und meinen Besitzer!! Kaufe einen Pass mit #pass premium```"
const smsGroup = () => "```Dieser Befehl kann nur in Gruppen benutzt werden!!```"
const smsPrivate = () => "```Dieser Befehl kann nur im Privatchat benutzt werden!!```"
const smsAdmin = () => "```Dieser Befehl ist nur für Admins!!```"
const smsBotAdmin = () => "```Ich muss Admin sein, damit du diesen Befehl benutzen kannst!!```"
const smsUnreg = () => "```Du musst dich registrieren, um diesen Befehl zu benutzen. Schreibe #verify!!```"
const smsRestrict = () => "```Dieser Befehl wurde von meinem Entwickler eingeschränkt!!```"

export default {
lenguaje,
smsAvisoRG,
smsAvisoAG,
smsAvisoIIG,
smsAvisoFG,
smsAvisoMG,
smsAvisoEEG,
smsAvisoEG,
smsRowner,
smsOwner,
smsMods,
smsPremium,
smsGroup,
smsPrivate,
smsAdmin,
smsBotAdmin,
smsUnreg,
smsRestrict
}
