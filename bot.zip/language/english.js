// language/english.js — الحزمة الأساسية (الإشعارات ورسائل الصلاحيات). المفاتيح الناقصة تُؤخذ من اللغة الافتراضية.
const lenguaje = () => "en"
const smsAvisoRG = () => "╰⊱✅⊱ *Result* ⊱✅⊱╮\n\n"
const smsAvisoAG = () => "╰⊱⚠️⊱ *Warning* ⊱⚠️⊱╮\n\n"
const smsAvisoIIG = () => "╰⊱❕⊱ *Info* ⊱❕⊱╮\n\n"
const smsAvisoFG = () => "╰⊱❌⊱ *Error* ⊱❌⊱╮\n\n"
const smsAvisoMG = () => "╰⊱❗️⊱ *Wrong usage* ⊱❗️⊱╮\n\n"
const smsAvisoEEG = () => "╰⊱📩⊱ *Report* ⊱📩⊱╮\n\n"
const smsAvisoEG = () => "╰⊱💚⊱ *Success* ⊱💚⊱╮\n\n"
const smsRowner = () => "```Only I, the bot's creator, can use this command!!```"
const smsOwner = () => "```Only my owner can use this command!!```"
const smsMods = () => "```Only moderators and my owner can use this command!!```"
const smsPremium = () => "```This command is only for premium users and my owner!! To get premium, buy a pass with #pass premium```"
const smsGroup = () => "```This command can only be used in groups!!```"
const smsPrivate = () => "```This command can only be used in private chat!!```"
const smsAdmin = () => "```This command is for admins only!!```"
const smsBotAdmin = () => "```I need to be an admin so you can use this command!!```"
const smsUnreg = () => "```You need to register to use this command, type #verify to register!!```"
const smsRestrict = () => "```This command is restricted by my developer!!```"

export default {
lenguaje,
smsAvisoRG,
smsAvisoAG,
smsAvisoIIG,
smsAvisoFG,
smsAvisoMG,
smsAvisoEEG,
smsAvisoEG,
smsRowner,
smsOwner,
smsMods,
smsPremium,
smsGroup,
smsPrivate,
smsAdmin,
smsBotAdmin,
smsUnreg,
smsRestrict
}
