// language/hindi.js — الحزمة الأساسية (الإشعارات ورسائل الصلاحيات). المفاتيح الناقصة تُؤخذ من اللغة الافتراضية.
const lenguaje = () => "hi"
const smsAvisoRG = () => "╰⊱✅⊱ *परिणाम* ⊱✅⊱╮\n\n"
const smsAvisoAG = () => "╰⊱⚠️⊱ *चेतावनी* ⊱⚠️⊱╮\n\n"
const smsAvisoIIG = () => "╰⊱❕⊱ *जानकारी* ⊱❕⊱╮\n\n"
const smsAvisoFG = () => "╰⊱❌⊱ *त्रुटि* ⊱❌⊱╮\n\n"
const smsAvisoMG = () => "╰⊱❗️⊱ *गलत उपयोग* ⊱❗️⊱╮\n\n"
const smsAvisoEEG = () => "╰⊱📩⊱ *रिपोर्ट* ⊱📩⊱╮\n\n"
const smsAvisoEG = () => "╰⊱💚⊱ *सफलता* ⊱💚⊱╮\n\n"
const smsRowner = () => "```यह कमांड केवल मैं, बॉट का निर्माता, उपयोग कर सकता हूँ!!```"
const smsOwner = () => "```यह कमांड केवल मेरा मालिक उपयोग कर सकता है!!```"
const smsMods = () => "```यह कमांड केवल मॉडरेटर और मेरा मालिक उपयोग कर सकते हैं!!```"
const smsPremium = () => "```यह कमांड केवल प्रीमियम उपयोगकर्ताओं और मेरे मालिक के लिए है!! प्रीमियम पाने के लिए #pass premium से पास खरीदें```"
const smsGroup = () => "```यह कमांड केवल ग्रुप में उपयोग की जा सकती है!!```"
const smsPrivate = () => "```यह कमांड केवल प्राइवेट चैट में उपयोग की जा सकती है!!```"
const smsAdmin = () => "```यह कमांड केवल एडमिन के लिए है!!```"
const smsBotAdmin = () => "```इस कमांड के उपयोग के लिए मुझे एडमिन होना ज़रूरी है!!```"
const smsUnreg = () => "```इस कमांड के लिए आपको रजिस्टर करना होगा, रजिस्टर करने के लिए #verify लिखें!!```"
const smsRestrict = () => "```यह कमांड मेरे डेवलपर द्वारा प्रतिबंधित है!!```"

export default {
lenguaje,
smsAvisoRG,
smsAvisoAG,
smsAvisoIIG,
smsAvisoFG,
smsAvisoMG,
smsAvisoEEG,
smsAvisoEG,
smsRowner,
smsOwner,
smsMods,
smsPremium,
smsGroup,
smsPrivate,
smsAdmin,
smsBotAdmin,
smsUnreg,
smsRestrict
}
