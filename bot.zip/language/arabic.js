// language/arabic.js — الحزمة الأساسية للعربية (الإشعارات ورسائل الصلاحيات).
// لو عندك ملف عربي كبير (مثل ar.js) خله جنبه: النظام يدمج الملفين، والمفتاح الموجود في الملف الكبير له الأولوية.
const lenguaje = () => 'ar'
const smsAvisoRG = () => "╰⊱✅⊱ *نتيجة* ⊱✅⊱╮\n\n"
const smsAvisoAG = () => "╰⊱⚠️⊱ *تنبيه* ⊱⚠️⊱╮\n\n"
const smsAvisoIIG = () => "╰⊱❕⊱ *معلومة* ⊱❕⊱╮\n\n"
const smsAvisoFG = () => "╰⊱❌⊱ *خطأ* ⊱❌⊱╮\n\n"
const smsAvisoMG = () => "╰⊱❗️⊱ *استخدام خاطئ* ⊱❗️⊱╮\n\n"
const smsAvisoEEG = () => "╰⊱📩⊱ *بلاغ* ⊱📩⊱╮\n\n"
const smsAvisoEG = () => "╰⊱💚⊱ *نجاح* ⊱💚⊱╮\n\n"
const smsRowner = () => "```هذا الأمر يستخدمه صانع البوت فقط!!```"
const smsOwner = () => "```هذا الأمر لمالك البوت فقط!!```"
const smsMods = () => "```هذا الأمر للمشرفين العامين ومالك البوت فقط!!```"
const smsPremium = () => "```هذا الأمر للمستخدمين المميزين ومالك البوت فقط!! للحصول على بريميوم اشترِ تذكرة بالأمر #pass premium```"
const smsGroup = () => "```هذا الأمر يعمل داخل المجموعات فقط!!```"
const smsPrivate = () => "```هذا الأمر يعمل في الخاص فقط!!```"
const smsAdmin = () => "```هذا الأمر لمشرفي المجموعة فقط!!```"
const smsBotAdmin = () => "```يجب أن أكون مشرفاً لتتمكن من استخدام هذا الأمر!!```"
const smsUnreg = () => "```يجب أن تسجّل أولاً لاستخدام هذا الأمر، اكتب #verify للتسجيل!!```"
const smsRestrict = () => "```هذا الأمر مقيّد من قبل المطوّر!!```"

export default {
lenguaje,
smsAvisoRG,
smsAvisoAG,
smsAvisoIIG,
smsAvisoFG,
smsAvisoMG,
smsAvisoEEG,
smsAvisoEG,
smsRowner,
smsOwner,
smsMods,
smsPremium,
smsGroup,
smsPrivate,
smsAdmin,
smsBotAdmin,
smsUnreg,
smsRestrict
}
